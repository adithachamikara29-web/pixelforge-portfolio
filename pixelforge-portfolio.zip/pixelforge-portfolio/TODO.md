# TODO

## Done (Milestone 1)
- [x] Portfolio page: hero, games, about, skills, services, contact, footer
- [x] Both game links and the mailto email link in the page
- [x] Responsive layout, mobile menu, reduced-motion support
- [x] Brand logo, favicon, and original card art for both games
- [x] JavaScript syntax checked and SVG files checked to be valid

## Needs checking by you
- [ ] Open index.html in your browser and look at it on phone and desktop (not visually tested yet)
- [ ] Click both Play buttons. The Apex link ends in `/a`. Check this is really your game address, not a typo.
- [ ] Click the email link

## Milestone 2 - logos
- [ ] Dropoff logo (SVG, PNG, square icon, social graphic) - first look at the real game
- [ ] Apex F1 Racer logo (same set), original, no F1 branding
- [ ] Use them on the site, replacing the card art if wanted

## Milestone 3 - video (30-45 s, 1920x1080, 30 FPS)
- [ ] Storyboard, script, and exact timings
- [ ] Render source (HTML/FFmpeg) and instructions. An MP4 only counts when it is really rendered.
- [ ] Add real gameplay clips you record yourself

## Milestone 4 - YouTube package
- [ ] Thumbnail 1280x720, 3 title options, description, tags, pinned comment, checklist
- [ ] Portfolio URL placeholder to fill in after publishing

## Milestone 5 - handover
- [ ] Final tests, ZIP, update README, TODO, CONTINUE_PROMPT
