/* ==========================================================
   SITE SETTINGS  -  edit the values below to change the site.
   (The HTML also has these values written in, so the page
   still works if JavaScript is turned off.)
   ========================================================== */
window.SITE = {
  brand: "PixelForge",                         // your developer name
  email: "adithachamikara29@gmail.com",        // your contact email
  year: new Date().getFullYear(),              // footer year (automatic)
  games: {
    dropoff: "https://dropoff.adithachamikara29.workers.dev/",
    apex:    "https://apexf1racer.adithachamikara29.workers.dev/a"
  }
};
