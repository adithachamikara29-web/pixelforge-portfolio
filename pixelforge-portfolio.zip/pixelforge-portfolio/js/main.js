/* PixelForge portfolio - main script. Plain JavaScript, no libraries. */
(function () {
  "use strict";
  var S = window.SITE || {};
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.documentElement.classList.add("js");

  /* ---- 1. Fill in settings from config.js ---- */
  function each(sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); }
  if (S.brand) each("[data-brand]", function (el) { el.textContent = S.brand; });
  if (S.email) {
    each("[data-email]", function (el) { el.textContent = S.email; });
    each("[data-mailto]", function (el) { el.href = "mailto:" + S.email; });
  }
  if (S.year) each("[data-year]", function (el) { el.textContent = S.year; });
  if (S.games) each("[data-game]", function (el) {
    var url = S.games[el.getAttribute("data-game")];
    if (url) el.href = url;
  });

  /* ---- 2. Mobile menu ---- */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("site-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    nav.addEventListener("click", function (e) {
      if (e.target.tagName === "A") { nav.classList.remove("open"); toggle.setAttribute("aria-expanded", "false"); }
    });
  }

  /* ---- 3. Scroll reveal (only for sections below the hero) ---- */
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.15 });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("in"); });
  }

  /* ---- 4. Typed code in the hero window ---- */
  var code = document.getElementById("typed-code");
  if (code) {
    var full = code.getAttribute("data-full") || code.textContent;
    if (reduceMotion) {
      code.textContent = full;
    } else {
      code.textContent = "";
      var i = 0;
      (function type() {
        code.textContent = full.slice(0, i);
        i += 2;
        if (i <= full.length + 1) setTimeout(type, 22);
      })();
    }
  }

  /* ---- 5. Copy email button ---- */
  var copyBtn = document.getElementById("copy-email");
  if (copyBtn && navigator.clipboard) {
    copyBtn.hidden = false;
    copyBtn.addEventListener("click", function () {
      navigator.clipboard.writeText(S.email || "").then(function () {
        copyBtn.textContent = "Copied";
        setTimeout(function () { copyBtn.textContent = "Copy email"; }, 1800);
      });
    });
  }

  /* ---- 6. Forge sparks (canvas). Skipped if reduced motion. ---- */
  var canvas = document.getElementById("sparks");
  if (!canvas || reduceMotion || !canvas.getContext) return;
  var ctx = canvas.getContext("2d");
  var w, h, sparks = [], running = true;
  var colors = ["#8b5cf6", "#4d7cff", "#22e5ff"];

  function resize() {
    var r = canvas.getBoundingClientRect();
    w = canvas.width = r.width; h = canvas.height = r.height;
    var count = Math.min(70, Math.floor(w / 18));
    sparks = [];
    for (var k = 0; k < count; k++) sparks.push(make(true));
  }
  function make(anywhere) {
    return {
      x: Math.random() * w,
      y: anywhere ? Math.random() * h : h + 10,
      s: 2 + Math.floor(Math.random() * 3),
      v: 0.25 + Math.random() * 0.8,
      d: (Math.random() - 0.5) * 0.3,
      c: colors[Math.floor(Math.random() * colors.length)],
      a: 0.25 + Math.random() * 0.5
    };
  }
  function frame() {
    if (!running) return;
    ctx.clearRect(0, 0, w, h);
    for (var k = 0; k < sparks.length; k++) {
      var p = sparks[k];
      p.y -= p.v; p.x += p.d;
      if (p.y < -10) sparks[k] = make(false);
      ctx.globalAlpha = p.a * Math.min(1, p.y / (h * 0.5) + 0.2);
      ctx.fillStyle = p.c;
      ctx.fillRect(Math.round(p.x), Math.round(p.y), p.s, p.s);
    }
    requestAnimationFrame(frame);
  }
  window.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", function () {
    running = !document.hidden; if (running) frame();
  });
  resize(); frame();
})();
