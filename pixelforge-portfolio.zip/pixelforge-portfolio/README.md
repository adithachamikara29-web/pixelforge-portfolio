# PixelForge Portfolio (Milestone 1)

A simple portfolio website made with plain HTML, CSS, and JavaScript. No tools or accounts needed to run it.

## What each file does
- `index.html` - the page: all the text and sections.
- `css/style.css` - colors, fonts, layout, and animations.
- `js/config.js` - **your settings**: name, email, game links.
- `js/main.js` - the moving parts: menu, scroll reveal, typed code, sparks.
- `assets/logos/brand-logo.svg` - the PixelForge logo.
- `assets/icons/favicon.svg` - the little icon in the browser tab.
- `assets/images/dropoff-card.svg`, `apex-card.svg` - the pictures on the game cards (original art, not screenshots).
- `TODO.md` - what is not done yet.
- `CONTINUE_PROMPT.md` - paste this into a new Claude chat to carry on.

## Open it on your computer
Double-click `index.html`. It opens in your browser.

## Change things
- **Name:** change `brand` in `js/config.js`. Also change the text `PixelForge` in `index.html` (search for it) so the page is right even without JavaScript. Also update the `<title>` line.
- **Email:** change `email` in `js/config.js`, and search `adithachamikara29@gmail.com` in `index.html` to change the written copies.
- **Game links:** change `games` in `js/config.js`, and the `href="https://..."` links in `index.html`.
- **Logo:** replace `assets/logos/brand-logo.svg` and `assets/icons/favicon.svg` with your own SVG files (same file names).
- **Colors and fonts:** edit the lines at the top of `css/style.css` under `:root`.
- **Text:** edit `index.html`. The words between the tags are what people read.

## Publish it for free
Free static hosts such as Cloudflare Pages (you already use Cloudflare Workers), GitHub Pages, or Netlify can host this folder. Each has its own rules about account ages, so check their current terms. Ask a parent or guardian to help set up any account you need. Do not enter a fake age.

## Not done yet
Game logos, the promo video, the thumbnail, and the YouTube text. See `TODO.md`.
